#!/bin/bash

for i in {0..300}
do
  echo "Spartan_$i" >> user-list.txt
done
